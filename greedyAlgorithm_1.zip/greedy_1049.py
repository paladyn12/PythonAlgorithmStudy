import sys
input = sys.stdin.readline

def findMin(a,b,c):
    if a<b and a<c:
        return a
    else:
        if b<c:
            return b
        else:
            return c
        

N, M = map(int,input().split())
stringType = []
for _ in range(M):
    stringType.append(list(map(int,input().split())))

stringType.sort(key=lambda x:x[0])
sixMin = stringType[0][0]
stringType.sort(key=lambda x:x[1])
singleMin = stringType[0][1]
firstRes = sixMin*(N//6 +1)
secondRes = sixMin*(N//6) + singleMin*(N%6)
thirdRes = singleMin*N
print(findMin(firstRes,secondRes,thirdRes))