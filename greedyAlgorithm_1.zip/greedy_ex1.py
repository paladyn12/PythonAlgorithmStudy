price = int(input())
count = 0
coinArray = [500,100,50,10]

for coin in coinArray:
    count += price//coin
    price%=coin

print(count)