from sys import stdin

str = stdin.readline()
strList = list(str)
count = 0
step = 0
for i in range(1,len(strList)-1):
    if strList[i] != strList[i-1]:
        if(step%2==0):
            count+=1
            step+=1
        else:
            step+=1
print(count)