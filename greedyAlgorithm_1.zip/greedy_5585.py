N = int(input())
N = 1000 - N
count = 0
coinList = [500,100,50,10,5,1]
for coin in coinList:
    if N >= coin:
        count += N//coin
        N -= N//coin * coin
print(count)