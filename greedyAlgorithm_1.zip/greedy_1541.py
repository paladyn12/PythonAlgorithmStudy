Str = input()
count = 0

Str = Str.split('+')
Str = [ele.lstrip('0') for ele in Str]
Str = '+'.join(Str)
Str = Str.split('-')
Str = [ele.lstrip('0') for ele in Str]
Str = '-'.join(Str)

Str = list(Str)

for i in range(len(Str)):
    if Str[i]=='+':
        if count != 0 :
            Str[i] = '-'
    if Str[i]=='-':
        count = 1
res = ''.join(Str)
print(eval(res))