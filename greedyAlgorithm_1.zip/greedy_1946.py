import sys

T = int(sys.stdin.readline())
for _ in range(T):

    N = int(sys.stdin.readline())
    recruitList = [0]*N
    for i in range(N):
        t1, t2 = map(int,sys.stdin.readline().split())
        recruitList[i] = [t1,t2]
    count = 1
    recruitList_1 = sorted(recruitList,key = lambda x:x[0])
    man = recruitList_1[0][1]
    for i in range(1,N):
        if recruitList_1[i][1] < man:
            count+=1
            man = recruitList_1[i][1]
    print(count)