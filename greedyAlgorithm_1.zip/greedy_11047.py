N, K = map(int,input().split())
coinList = []
count = 0
for i in range(N):
    coinList.append(int(input()))
coinList.sort(reverse=True)
for i in coinList:
    if(i<=K):
        count += K//i
        K -= i*(K//i)
print(count)