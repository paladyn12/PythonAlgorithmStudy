import sys
import heapq
input = sys.stdin.readline

N, K = map(int,input().split())
jewelList = [list(map(int,input().split())) for _ in range(N)]
bagList = [int(input()) for _ in range(K)]
jewelList.sort()
bagList.sort()

sum = 0
temp = []

for bag in bagList:
    while jewelList and bag >= jewelList[0][0]:
        heapq.heappush(temp,-jewelList[0][1])
        heapq.heappop(jewelList)
    if temp:
        sum+=heapq.heappop(temp)

print(-sum)