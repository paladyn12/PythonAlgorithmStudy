N = int(input())
lopeList = []
for i in range(N):
    lopeList.append(int(input()))
lopeList.sort(reverse=True) 
for i in range(N):
    lopeList[i] = lopeList[i]*(i+1)
lopeList.sort(reverse=True)

print(lopeList[0])