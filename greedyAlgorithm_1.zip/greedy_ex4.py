n = int(input())
X = list(map(int,input().split()))
X.sort()
stepIndex = 0
count = 0

while(True):
    stepIndex += X[stepIndex]
    if(stepIndex >= n):
        break
    count += 1

print(count)