import sys
input = sys.stdin.readline

def comparingList(a:list,b:list):
    if a[1]<=b[0] or a[0]>=b[1]:
        return 0
    else:
        return 1

N = int(input())
meetingList = []
for _ in range(N):
    meetingList.append(list(map(int,input().split())))
meetingList.sort(key = lambda x:x[1]-x[0],reverse=True)
resultList = []
for ml in meetingList:
    for rl in resultList:
        if comparingList(ml,rl):
            resultList.remove(rl)
            break
    resultList.append(ml)
    
print(len(resultList))