N = int(input())
count = 0
step = 1

while(True):
    if(step*2 >= N):
        break
    else:
        count+=1
        N-=step
        step+=1

print(count+1)