S = input()
result = 0
for n in S:
    n = int(n)
    if(n <= 1):
        result += n
    else:
        if(result <= 1):
            result+=n
        else:
            result *= n

print(result)