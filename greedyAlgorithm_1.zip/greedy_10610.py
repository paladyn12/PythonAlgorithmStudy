N = list(map(int,input()))
sum = 0
Str = ''
if(0 not in N):
    print(-1)
else:
    for i in N:
        sum+=i  
    if(sum%3 != 0):
        print(-1)
    else:
        N.sort(reverse=True)
        for i in N:
            Str += str(i)
        print(int(Str))