import sys

L,P,V = map(int,sys.stdin.readline().rstrip().split())

testCase = 1

while(L+P+V != 0):
    if(V%P >= L):
        result = L*(V//P) + L
    else:
        result = L*(V//P) + V%P
    print(f'Case {testCase}: {result}')
    testCase += 1
    L,P,V = map(int,sys.stdin.readline().rstrip().split())