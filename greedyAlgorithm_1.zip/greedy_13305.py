N = int(input())
roadLength = list(map(int,input().split()))
oilPrice = list(map(int,input().split()))
sum = 0
for i in range(1,N):
    if(oilPrice[i-1]<oilPrice[i]):
        oilPrice[i] = oilPrice[i-1]
for i in range(N-1):
    sum += roadLength[i]*oilPrice[i]

print(sum)