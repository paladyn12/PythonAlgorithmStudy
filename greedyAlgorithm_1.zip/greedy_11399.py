n = int(input())
Pi = list(map(int,input().split()))
Pi.sort()
sum = 0
for i in Pi:
    sum += i*n
    n-=1
print(sum)