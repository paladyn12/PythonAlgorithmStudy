T = int(input())
A = 0
B = 0
C = 0
if T%10 != 0:
    print(-1)
else:
    A = T//300
    T -= 300 * A
    B = T//60
    T -= 60 * B
    C = T//10
    T -= 10 * C
    print(A,B,C)