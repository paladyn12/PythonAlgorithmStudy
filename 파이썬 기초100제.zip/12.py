a = int(input())
b = int(input())
print(a)
print(b)