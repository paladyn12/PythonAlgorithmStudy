start,r,d,n = input().split()
start = int(start)
r = int(r)
d = int(d)
n = int(n)
for i in range(n-1):
    start*=r
    start+=d
print(start)