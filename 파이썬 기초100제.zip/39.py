f1,f2 = input().split()
f1 = float(f1)
f2 = float(f2)
print(f1**f2)