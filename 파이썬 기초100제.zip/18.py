a,b = input().split(':')
print(f'{a}:{b}')