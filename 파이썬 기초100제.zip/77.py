sum = 0
n = int(input())
for i in range(n+1):
    if(i%2==0): sum+=i
print(sum)