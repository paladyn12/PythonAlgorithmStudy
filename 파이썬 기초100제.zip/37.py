n = int(input())
s = input()
print(n*s)