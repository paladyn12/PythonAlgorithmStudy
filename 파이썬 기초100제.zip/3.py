print('Hello')
print('World')