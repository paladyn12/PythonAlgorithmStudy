c = input()
c = ord(c)
c+=1
print(chr(c))