n = int(input())
print(chr(n))