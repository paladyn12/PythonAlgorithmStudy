n = int(input())
step=1
sum=0
while(sum<n):
    sum+=step
    step+=1
print(sum)