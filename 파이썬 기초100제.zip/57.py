c,d = input().split()
print(bool(int(c))==bool(int(d)))