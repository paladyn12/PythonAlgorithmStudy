sum = 0
step = 0
n = int(input())
while(sum<n):
    step+=1
    sum+=step
print(step)