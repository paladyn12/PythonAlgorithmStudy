a = input()
a = int(a)
print('%X'% a)