h,w = input().split()
h = int(h)
w = int(w)
Array = []
for i in range(h):
    Array.append([])
    for j in range(w):
        Array[i].append(0)
n = int(input())
for i in range(n):
    l,d,x,y = input().split()
    l = int(l)
    d = int(d)
    x = int(x)-1
    y = int(y)-1
    if d == 1:
        for j in range(l):
            Array[x+j][y]= 1
    else:
        for j in range(l):
            Array[x][y+j]= 1

for i in range(h):
    for j in range(w):
        print(Array[i][j],end=' ')
    print()