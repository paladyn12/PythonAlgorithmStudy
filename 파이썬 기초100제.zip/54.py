a,b = input().split()
print(bool(int(a)) and bool(int(b)))