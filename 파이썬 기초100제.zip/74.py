c = ord(input())
n = ord('a')
while(c!=(n-1)):
    print(chr(n),end=' ')
    n+=1