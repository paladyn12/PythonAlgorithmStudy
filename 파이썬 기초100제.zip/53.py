n = bool(int(input()))
print(not n)