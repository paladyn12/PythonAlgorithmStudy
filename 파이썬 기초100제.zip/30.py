n = ord(input())
print(n)