n = 1
while(n!=0):
    n = int(input())
    if(n!=0): print(n)