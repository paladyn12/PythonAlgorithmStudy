a = float(input())
b = float(input())
print(a+b)