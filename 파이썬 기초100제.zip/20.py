n1,n2 = input().split('-')
print(n1+n2)