w1,w2 = input().split()
print(w1+w2)