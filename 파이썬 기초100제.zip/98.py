Array = []
for i in range(10):
    addLine = input().split()
    for j in range(10):
        addLine[j] = int(addLine[j])
    Array.append(addLine)

StepX = 1
StepY = 1
StopWhile = 0

while(StopWhile==0):
    if(Array[StepX][StepY+1]==0 or Array[StepX][StepY+1]==2):
        Array[StepX][StepY]=9
        StepY+=1
    else:
        if(Array[StepX+1][StepY]==0 or Array[StepX+1][StepY]==2):
            Array[StepX][StepY]=9
            StepX+=1
        else:
            Array[StepX][StepY]=9
            StopWhile+=1
    if(Array[StepX][StepY]==2):
        Array[StepX][StepY]=9
        StopWhile+=1

for i in range(10):
    for j in range(10):
        print(Array[i][j],end=' ')
    print()