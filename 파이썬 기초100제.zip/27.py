a = input()
a = int(a)
print('%x'% a)