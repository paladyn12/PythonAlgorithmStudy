n1,n2 = input().split()
n1 = float(n1)
n2 = float(n2)
print(n1*n2)