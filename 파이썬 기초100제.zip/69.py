c = input()
if(c=='A'):
    print('best!!!')
elif(c=='B'):
    print('good!!')
elif(c=='C'):
    print('run!')
elif(c=='D'):
    print('slowly~')
else:
    print('what?')