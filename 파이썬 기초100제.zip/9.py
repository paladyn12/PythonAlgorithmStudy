a = input()
print(a)