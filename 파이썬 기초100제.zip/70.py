m = int(input())
if(m//3 == 1):
    print('spring')
elif(m//3 == 2):
    print('summer')
elif(m//3 == 3):
    print('fall')
else:
    print('winter') 