n = float(input())
print(n)
print(n)
print(n)