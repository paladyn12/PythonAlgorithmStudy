a = input()
print(a,a,a)