count = 1
while(True):
    c = input()
    if(count==1):
        print(c)
    if(c=='q'):
        count-=1