c,d = input().split()
print(not(bool(int(c))) and not(bool(int(d))))