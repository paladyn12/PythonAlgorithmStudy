a = input()
a = int(a,16)
print('%o'% a)