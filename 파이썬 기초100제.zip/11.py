a = float(input())
print(a)