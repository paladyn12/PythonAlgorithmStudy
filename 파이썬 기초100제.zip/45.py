a,b,c = input().split()
a = int(a)
b = int(b)
c = int(c)
sum = a+b+c
div = float(a+b+c)/3
print(sum,format(div,".2f"))