f1,f2 = input().split()
f1 = float(f1)
f2 = float(f2)
res = f1/f2
print(format(res,".3f"))