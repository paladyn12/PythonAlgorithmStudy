start,r,n = input().split()
start = int(start)
r = int(r)
n = int(n)
for i in range(n-1):
    start*=r
print(start)