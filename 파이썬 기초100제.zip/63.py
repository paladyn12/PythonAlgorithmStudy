a,b = input().split()
a = int(a)
b = int(b)
c = a if a>=b else b
print(c)