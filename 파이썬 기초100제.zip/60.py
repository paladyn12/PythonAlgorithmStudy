c,d = input().split()
c = int(c)
d = int(d)
print(c&d)