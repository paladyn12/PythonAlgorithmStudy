n = int(input())
step = 0
while(step!=(n+1)):
    print(step)
    step+=1