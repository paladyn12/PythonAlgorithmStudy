a = float(input())
print(format(a,".2f"))