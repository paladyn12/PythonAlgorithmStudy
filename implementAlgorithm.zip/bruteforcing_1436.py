import sys
input = sys.stdin.readline

result = []
i = 0
N = int(input().rstrip())


while(len(result)<=10000):
    if('666' in str(i)):
        result.append(i)
    i+=1

print(result[N-1])