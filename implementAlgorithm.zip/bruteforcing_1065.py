import sys
input = sys.stdin.readline

N = int(input())

sum = 0
for i in range(1,N+1):
    if i<100: sum+=1
    else:
        if i//100 - (i//10)%10 == (i//10)%10 - i%10:
            sum+=1

print(sum)