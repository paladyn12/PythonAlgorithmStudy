numList = []
for i in range(1,10001):
    numList.append(i)
for i in range(1,10000):
    res = i+i//1000+(i//100)%10+(i//10)%10+i%10
    if res in numList: numList.remove(res)
for n in numList:
    print(n)