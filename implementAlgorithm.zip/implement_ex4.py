import sys
input = sys.stdin.readline

line = list(input().rstrip())
chrLine = []
numLine = []
for a in line:
    if 65<=ord(a)<=90:
        chrLine.append(a)
    else:
        c=numLine.append(a)
chrLine.sort()
sum = 0
for n in numLine:
    sum+=int(n)
Chr = ''.join(chrLine)

print(Chr,end='')
print(sum)