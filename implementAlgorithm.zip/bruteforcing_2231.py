import sys
input = sys.stdin.readline

N = int(input())
numList = []
for i in range(1,N+1):
    sum=0
    numList = list(str(i))
    for n in numList:
        sum+=int(n)
    if i+sum==N:
        print(i)
        break
if i == N: print(0)