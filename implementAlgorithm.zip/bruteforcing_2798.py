import sys
input = sys.stdin.readline

N,M = map(int,input().split())

max = 0
cardList = list(map(int,input().split()))
for i in range(N):
    for j in range(i+1,N):
        for k in range(j+1,N):
            sum=cardList[i]+cardList[j]+cardList[k]
            if sum>M: continue
            else:
                if sum>max: max=sum

print(max)