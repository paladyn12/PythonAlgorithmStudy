import sys
input = sys.stdin.readline

N, M = map(int,input().split())
chessMap = []
for _ in range(N):
    str = input().rstrip()
    chessMap.append(list(str))

result = []

for i in range(0,N-7):
    for j in range(0,M-7):
        draw1=0
        draw2=0
        for a in range(i,i+8):
            for b in range(j,j+8):
                if (a+b)%2 == 0:
                    if chessMap[a][b] == 'B':
                        draw1+=1
                    else:
                        draw2+=1
                else:
                    if chessMap[a][b] == 'W':
                        draw1+=1
                    else:
                        draw2+=1
        result.append(draw1)
        result.append(draw2)
        
print(min(result))