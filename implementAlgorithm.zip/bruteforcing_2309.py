import sys
input = sys.stdin.readline

short = []

for _ in range(9):
    short.append(int(input()))
    
short.sort()
idx = []
count=0

for a in range(0,3):
    for b in range(a+1,4):
        for c in range(b+1,5):
           for d in range(c+1,6):
               for e in range(d+1,7):
                    for f in range(e+1,8):
                        for g in range(f+1,9):
                            if(count==0):
                                if(short[a]+short[b]+short[c]+short[d]+short[e]+short[f]+short[g] == 100):
                                    idx.append(a)
                                    idx.append(b)
                                    idx.append(c)
                                    idx.append(d)
                                    idx.append(e)
                                    idx.append(f)
                                    idx.append(g)
                                    count+=1
                                    break
for id in idx:
    print(short[id])