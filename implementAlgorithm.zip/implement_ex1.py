import sys
input = sys.stdin.readline

N = int(input())
plans = input().split()
dx = [0,0,1,-1]
dy = [1,-1,0,0]
directionType = ['R','L','D','U']

map = []
for _ in range(N):
    map.append([0]*N)

x=0
y=0

for plan in plans:
    for i in range(len(directionType)):
        if plan == directionType[i]:
            nx = x + dx[i]
            ny = y + dy[i]
            if nx<0 or ny<0 or nx>N-1 or ny>N-1:
                continue
            x,y = nx,ny
print(x+1,y+1)