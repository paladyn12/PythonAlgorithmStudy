import sys
input = sys.stdin.readline

location = input()
print(location[0],location[1])

x = int(location[1])-1
y = ord(location[0])-97

dx = [-2,-1,1,2,1,2,-1,-2]
dy = [1,2,2,1,-1,-2,-2,-1]

count = 0

for i in range(8):
    nx = x+dx[i]
    ny = y+dy[i]
    if 0<=nx<=7 and 0<=ny<=7:
        count+=1

print(count)