import sys
input = sys.stdin.readline

N = int(input())
sum = 0
for n in range(N+1):
    if n%10 == 3:
        sum += 60*60
    else:
        for i in range(60):
            for j in range(60):
                if i%10==3 or i//10==3 or j%10==3 or j//10==3:
                    sum+=1
print(sum)