import sys
input = sys.stdin.readline

N = int(input())
sizeList = []
for _ in range(N):
    sizeList.append(list(map(int,input().split())))
scoreList = [0]*N
for i in range(N):
    sum=0
    for j in range(N):
        if i==j:
            continue
        if(sizeList[i][0]<sizeList[j][0] and sizeList[i][1]<sizeList[j][1]):
            sum+=1
    scoreList[i] = sum

for n in scoreList:
    print(n+1)