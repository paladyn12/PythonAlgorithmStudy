package com.example.baekjoonstep3

import java.util.*

fun main(Args: Array<String>) = with(Scanner(System.`in`)){
    var t = nextInt()
    var A : Int
    var B : Int
    for(i in 1..t){
        A = nextInt()
        B = nextInt()
        println(A+B)
    }
}