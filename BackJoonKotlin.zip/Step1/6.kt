package com.example.baekjoonstep1

import java.util.*

fun main(Args : Array<String>) = with (Scanner(System.`in`)){
    var a = nextInt()
    var b = nextInt()
    println(a-b)
}