package com.example.baekjoonstep1

import java.util.*

fun main(Args : Array<String>) = with (Scanner(System.`in`)){
    var name = nextLine()
    println(name+"??!")
}