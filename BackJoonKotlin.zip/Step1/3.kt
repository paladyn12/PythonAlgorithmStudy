package com.example.baekjoonstep1

fun main(){
    println("\\    /\\\n" +
            " )  ( ')\n" +
            "(  /  )\n" +
            " \\(__)|")
}