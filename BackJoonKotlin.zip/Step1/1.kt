package com.example.baekjoonstep1

fun main(){
    println("Hello World!")
}