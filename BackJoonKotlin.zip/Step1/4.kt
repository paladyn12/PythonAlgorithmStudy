package com.example.baekjoonstep1

fun main(){
    println("|\\_/|\n" +
            "|q p|   /}\n" +
            "( 0 )\"\"\"\\\n" +
            "|\"^\"`    |\n" +
            "||_/=\\\\__|")
}