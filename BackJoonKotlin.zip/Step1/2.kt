package com.example.baekjoonstep1

fun main(){
    println("강한친구 대한육군")
    println("강한친구 대한육군")
}