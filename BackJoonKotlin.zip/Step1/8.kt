package com.example.baekjoonstep1

import java.util.*

fun main(Args : Array<String>) = with (Scanner(System.`in`)){
    var a = nextDouble()
    var b = nextDouble()
    var c : Double = a/b
    println(c)
}