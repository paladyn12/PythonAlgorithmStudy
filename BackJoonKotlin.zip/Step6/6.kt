package com.example.baekjoonstep6

import java.util.*

fun main(Args:Array<String>) = with(Scanner(System.`in`)){
    print(StringTokenizer(nextLine()," ").countTokens())
}